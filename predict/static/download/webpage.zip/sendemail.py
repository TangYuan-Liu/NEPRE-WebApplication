import smtplib 
from email.mime.text import MIMEText
import time

def sendtouser( toaddrs, msg ):
  fromaddr = 'sastbx@163.com' 
  # Credentials (if needed) 
  username = 'sastbx' 
  password = '1q2w3e4r0' 
  new_msg = MIMEText(msg)
  new_msg['Subject']= 'Results from the SASTBX Webserver, sent at ' +time.ctime()
  new_msg['From'] = fromaddr
  new_msg['To'] = toaddrs

  # The actual mail send 
  server = smtplib.SMTP('smtp.163.com:25') 
  server.starttls() 
  server.login(username,password) 
  server.sendmail(fromaddr, toaddrs, new_msg.as_string() ) 
  server.quit() 


def tst():
  sendtouser( 'sastbx@163.com', 'test' )

if __name__ == "__main__":
  tst()
