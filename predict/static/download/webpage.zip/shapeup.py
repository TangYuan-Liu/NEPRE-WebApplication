from cctbx.web import io_utils
from cctbx.web import cgi_utils
import os, time, sys
from libtbx.test_utils import run_command
from sendemail import sendtouser

def interpret_form_data(form):
  inp = cgi_utils.inp_from_form(form,
    (("email", None),
     ("db", None),
     ("radius", None),
     ("qmax", None),
     ("scan", None),
     ("saxs_file", None),
     ("pdb_file", None)
    ))
  return inp


def run(server_info, inp, status):
  print "<html><pre>"
#  print '<META HTTP-EQUIV="REFRESH" CONTENT="5">'

  email = inp.email
  db = inp.db
  radius = inp.radius
  qmax = inp.qmax
  scan = inp.scan
  saxs_data= inp.saxs_file
  pdb_model= inp.pdb_file

  command='sastbx.shapeup nmax=10 ' + ' scan=' + scan + ' qmax=' + qmax + ' '
  time_stamp = str( time.time() )
  tmpdir = '../results/'+ time_stamp
  os.mkdir(tmpdir)
  saxs_name = tmpdir+'/saxs.dat'
  open(saxs_name, 'w').write(saxs_data)
  command = command + 'target=saxs.dat '
  command = command + 'db_choice='+db+' '
  if( radius is not None):
    command = command + 'rmax='+radius+' '
  if(pdb_model is not None):
    pdb_name = tmpdir+'/model.pdb'
    open(pdb_name, 'w').write(pdb_model)
    command = command + 'pdb=model.pdb ' #+ pdb_name



  current_path=os.getcwd()
  os.chdir(tmpdir)
  shell_cmd = open('runme.csh', 'w')
  print>>shell_cmd, '''#!/bin/csh -f
source /Users/hgliu/cctbx/build/setpaths_all.csh
echo '<html><pre><META HTTP-EQUIV="REFRESH" CONTENT="10">' > shapeup_log.html
echo '<html><pre><META HTTP-EQUIV="REFRESH" CONTENT="5"> Retriving... This page will be refreshed every 5 seconds</pre><html>' > models.html
'''
  print>>shell_cmd, command+'>>& shapeup_log.html &'
  shell_cmd.close()
  run_command('chmod a+x runme.csh')
  run_command('./runme.csh')
  print "Job Submitted, the results should be ready in about <strong> One Minute </strong>!"
  print 'Click <a href=../results/%s/shapeup_log.html> Here </a> to check the status of the job'%time_stamp
  print 'Click <a href=../results/%s/models.html> Here </a> to view the models'%time_stamp
  print 'Click <a href=%s/models.tgz> Here </a> to Download all models (Need to wait for 1 minute, until the process is finished'%tmpdir

  msg = '''
  Thanks for using sastbx!\n
  Please see the results directed by the links below. If you have any question/suggestion, please let us know. \n\n
  Click <a href=../results/%s/shapeup_log.html> Here </a> to check the status of the job\n
  Click <a href=../results/%s/models.html> Here </a> to view all the models\n
  Click <a href=../results/%s/models.tgz> Here </a> to download all the models\n
  If you Reply this email, we will take a look at the model/data, and hopefully can improve the results. \n
  Best, SASTBX TEAM @ LBL
  '''%(time_stamp, time_stamp, time_stamp)

  if(email is not None) and ( '@' in email ):
    print 
    print "The above info has been sent to your <strong>email</strong> as well, please check spam folder if it is not there."
    sendtouser( email, msg )
  else:
    print "\nThe <strong>email</strong> address is not properly filled, we will not be able to contact you if there is anything wrong with the models."
    print "We strongly recommend you to provide an valid email for following up contacts."
    sendtouser( 'sastbx@gmail.com', msg )

  
#  command = command + '&'
#  run_command(command, buffered=False)
  #os.chdir(current_path)
  #link2result( tmpdir, time_stamp ) 

  print "</pre></html>"
